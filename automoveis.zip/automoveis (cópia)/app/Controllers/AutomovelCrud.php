<?php 
namespace App\Controllers;
use App\Models\AutomovelModel;
use CodeIgniter\Controller;

class AutomovelCrud extends Controller
{
    // show automoveis list
    public function index(){
        $automovelModel = new AutomovelModel();
        $data['automoveis'] = $automovelModel->orderBy('id', 'DESC')->findAll();
        return view('automovel_view', $data);
    }
    // add automovel form
    public function create(){
        return view('add_automovel');
    }
 
    // insert data
    public function store() {
        $automovelModel = new AutomovelModel();
        $data = [
            'descricao' => $this->request->getVar('descricao'),
            'placa'  => strtoupper($this->request->getVar('placa')),
            'ar_condicionado'  => empty($this->request->getVar('ar_condicionado')) ? '0' : '1',
            'direcao_hidraulica'  => empty($this->request->getVar('direcao_hidraulica')) ? '0' : '1',
        ];
        $automovelModel->insert($data);
        return $this->response->redirect(site_url('/automoveis-list'));
    }
    // show single automovel
    public function singleAutomovel($id = null){
        $automovelModel = new AutomovelModel();
        $data['automovel_obj'] = $automovelModel->where('id', $id)->first();
        return view('edit_views', $data);
    }
    // update automovel data
    public function update(){
        $automovelModel = new AutomovelModel();
        $id = $this->request->getVar('id');
        if (empty($id)) 
            $this->store();
        
        $data = [
            'descricao' => $this->request->getVar('descricao'),
            'placa'  => strtoupper($this->request->getVar('placa')),
            'ar_condicionado'  => empty($this->request->getVar('ar_condicionado')) ? '0' : '1',
            'direcao_hidraulica'  => empty($this->request->getVar('direcao_hidraulica')) ? '0' : '1',
        ];
        $automovelModel->update($id, $data);
        return $this->response->redirect(site_url('/automoveis-list'));
    }
 
    // delete automovel
    public function delete($id = null){
        $automovelModel = new AutomovelModel();
        $data['automovel'] = $automovelModel->where('id', $id)->delete($id);
        return $this->response->redirect(site_url('/automoveis-list'));
    }    

    public function deleteMulti($ids = null){
        $automovelModel = new AutomovelModel();
        $listIds = explode(',', $ids);
        foreach ($listIds as $id) {
            $data['automovel'] = $automovelModel->where('id', $id)->delete($id);
        }
        return $this->response->redirect(site_url('/automoveis-list'));
    }    
}