<?php
namespace App\Models;
use CodeIgniter\Model;

class AutomovelModel extends Model
{
    protected $table = 'automoveis';
    protected $primaryKey = 'id';

    protected $allowedFields = ['descricao', 'placa', 'ar_condicionado', 'direcao_hidraulica'];
}