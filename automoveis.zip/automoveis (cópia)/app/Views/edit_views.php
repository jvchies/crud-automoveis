<!DOCTYPE html>
<html>
<head>
  <title>CRUD Automóveis</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <style>
    .container {
      max-width: 500px;
    }
    .error {
      display: block;
      padding-top: 5px;
      font-size: 14px;
      color: red;
    }
  </style>
</head>
<body>
  <div class="container mt-5">
    <form method="post" id="update_automovel" name="update_automovel" 
    action="<?= site_url('/update') ?>">
      <input type="hidden" name="id" id="id" value="<?php echo isset($automovel_obj['id']) ? $automovel_obj['id'] : ''; ?>">
      <div class="form-group">
        <label for="descricao">Descrição</label>
        <input type="text" maxlength="60" name="descricao" id="descricao" class="form-control" value="<?php echo isset($automovel_obj['descricao']) ? $automovel_obj['descricao'] : ''; ?>">
      </div>
      <div class="form-group">
        <label for="placa">Placa</label>
        <input type="text" maxlength="7" name="placa" id="placa" class="form-control" value="<?php echo isset($automovel_obj['placa']) ? $automovel_obj['placa'] : ''; ?>">
      </div>
      <div class="form-group">
      <input style="width: 15px" type="checkbox" name="ar_condicionado" id="ar_condicionado" onclick="updateCheckbox('ar_condicionado')" value="<?php echo isset($automovel_obj['ar_condicionado']) ? $automovel_obj['ar_condicionado'] : ''; ?>">
        <label for="ar_condicionado">
         Ar condicionado
        </label>
      </div>
      <div class="form-group">
      <input style="width: 15px" type="checkbox" name="direcao_hidraulica" id="direcao_hidraulica" onclick="updateCheckbox('direcao_hidraulica')" value="<?php echo isset($automovel_obj['direcao_hidraulica']) ? $automovel_obj['direcao_hidraulica'] : ''; ?>">
        <label for="direcao_hidraulica">
         Direção hidráulica
        </label>
      </div>
      <div class="form-group">
        <a href="<?php echo site_url('/') ?>" class="btn btn-secondary"><i class="bi bi-back"></i> Voltar</a>
        <button type="submit" class="btn btn-success">Salvar</button>
      </div>
    </form>
  </div>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/additional-methods.min.js"></script>
  <script>
    if ($("#update_automovel").length > 0) {
      $("#update_automovel").validate({
        rules: {
          descricao: {
            required: true,
            maxlength: 60,
          },
          placa: {
            required: true,
            maxlength: 7,
            minlength: 7,
          },
        },
        messages: {
          descricao: {
            required: "A descrição é obrigatória.",
            maxlength: "A descrição pode conter até 60 caracteres.",
          },
          placa: {
            required: "A placa é obrigatória.",
            maxlength: "A placa deve conter 7 caracteres.",
            minlength: "A placa deve conter 7 caracteres.",
          },
        },
      })
    }
  </script>
  <script>
    $(document).ready( function () {
      $(':checkbox').each( function () {
        if (this.value === "1") {
          $(this).prop('checked', true);
        }
        });
      });
  </script>
  <script>
    $(':checkbox').change(function(){
    this.value = (Number(this.checked));
});
  </script>
</body>
</html>