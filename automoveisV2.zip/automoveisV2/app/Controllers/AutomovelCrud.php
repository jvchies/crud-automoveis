<?php 
namespace App\Controllers;
use App\Models\AutomovelModel;
use App\Models\ComponentesAdicionaisModel;
use App\Models\AutoAdicionalModel;
use CodeIgniter\Controller;

class AutomovelCrud extends Controller
{
    // const RULES = [
    //     'descricao' => 'required|max_length[60]',
    //     'placa' => 'required|max_length[7]|min_length[7]|numeric',
    //     'codigo_renavam' => 'required|max_length[11]',
    //     'ano_modelo' => 'required|max_length[7]|min_length[7]|numeric',
    //     'ano_fabricacao' => 'required|max_length[7]|min_length[7]|numeric',
    //     'cor' => 'required|max_length[20]',
    //     'km' => 'required|max_length[6]|numeric',
    //     'marca' => 'required|max_length[20]',
    //     'preco' => 'required|decimal',
    //     'preco_fipe' => 'required|decimal',
    // ];

    public function index(){
        $automovelModel = new AutomovelModel();
        $data['automoveis'] = $automovelModel->orderBy('id', 'DESC')->findAll();
        return view('automovel_view', $data);
        // return json_encode($data);
    }

    public function create(){
        return view('add_automovel');
    }
 
    public function store() {
        $automovelModel = new AutomovelModel();
        $autoAdicionalModel = new AutoAdicionalModel();
        $componenteModel = new ComponentesAdicionaisModel();

        $automovel = [
            'descricao' => $this->request->getVar('descricao'),
            'placa'  => strtoupper($this->request->getVar('placa')),
            'codigo_renavam' => $this->request->getVar('codigo_renavam'),
            'ano_modelo' => $this->request->getVar('ano_modelo'),
            'ano_fabricacao' => $this->request->getVar('ano_fabricacao'),
            'cor' => $this->request->getVar('cor'),
            'km' => $this->request->getVar('km'),
            'marca' => $this->request->getVar('marca'),
            'preco' => $this->request->getVar('preco'),
            'preco_fipe' => $this->request->getVar('preco_fipe'),        
        ];
        $idAutomovel = $automovelModel->insert($automovel);
        
        $componentes = $_POST['componentes'];
        foreach ($componentes as $comp) {
            $data = [
                'idAutomovel'  => $idAutomovel,
                'idAdicional' => $comp,
            ];
            $autoAdicionalModel->insert($data);
        }

        return $this->response->redirect(site_url('/automoveis-list'));
    }

    public function singleAutomovel($id = null){
        $automovelModel = new AutomovelModel();
        $autoAdicionalModel = new AutoAdicionalModel();
        $componenteModel = new ComponentesAdicionaisModel();

        $data['automovel_obj'] = $automovelModel->where('id', $id)->first();
        $data['auto_adicional'] = $autoAdicionalModel->select('idAdicional')->where('idAutomovel', $id)->findAll();
        $data['componentes'] = $componenteModel->findAll();

        $list_adicional = [];
        foreach ($data['auto_adicional'] as $auto_adicional) {
            $list_adicional[] = $auto_adicional['idAdicional'];
        }

        $i = 0;
        foreach ($data['componentes'] as $componente) {
            if (in_array($componente['id'], $list_adicional)) {
                $data['componentes'][$i]['checked'] = 'checked';
            } else {
                $data['componentes'][$i]['checked'] = '';
            }
            $i++;
        }

        return view('edit_views', $data);
    }

    public function update(){
        $automovelModel = new AutomovelModel();
        $autoAdicionalModel = new AutoAdicionalModel();
        $componenteModel = new ComponentesAdicionaisModel();

        $id = $this->request->getVar('id');
        if (empty($id)) 
            $this->store();
        
        $data = [
            'descricao' => $this->request->getVar('descricao'),
            'placa'  => strtoupper($this->request->getVar('placa')),
            'codigo_renavam' => $this->request->getVar('codigo_renavam'),
            'ano_modelo' => $this->request->getVar('ano_modelo'),
            'ano_fabricacao' => $this->request->getVar('ano_fabricacao'),
            'cor' => $this->request->getVar('cor'),
            'km' => $this->request->getVar('km'),
            'marca' => $this->request->getVar('marca'),
            'preco' => $this->request->getVar('preco'),
            'preco_fipe' => $this->request->getVar('preco_fipe'),        
        ];
        $automovelModel->update($id, $data);

        $autoAdicionalModel->where('idAutomovel', $id)->delete();
        if (isset($_POST['componentes'])) {
            $componentes = $_POST['componentes'];
            foreach ($componentes as $comp) {
                $data = [
                    'idAutomovel'  => $id,
                    'idAdicional' => $comp,
                ];
                $autoAdicionalModel->insert($data);
            }
        }

        return $this->response->redirect(site_url('/automoveis-list'));
    }

    public function delete($id = null){
        $automovelModel = new AutomovelModel();
        $autoAdicionalModel = new AutoAdicionalModel();

        $autoAdicionalModel->where('idAutomovel', $id)->delete();
        $data['automovel'] = $automovelModel->where('id', $id)->delete($id);
        return $this->response->redirect(site_url('/automoveis-list'));
    }    

    public function deleteMulti($ids = null){
        $automovelModel = new AutomovelModel();
        $autoAdicionalModel = new AutoAdicionalModel();
        
        $listIds = explode(',', $ids);
        foreach ($listIds as $id) {
            $autoAdicionalModel->where('idAutomovel', $id)->delete();
            $data['automovel'] = $automovelModel->where('id', $id)->delete($id);
        }
        return $this->response->redirect(site_url('/automoveis-list'));
    }    
}