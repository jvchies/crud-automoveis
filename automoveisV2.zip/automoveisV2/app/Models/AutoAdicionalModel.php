<?php
namespace App\Models;
use CodeIgniter\Model;

class AutoAdicionalModel extends Model
{
    protected $table = 'auto_adicional';
    protected $primaryKey = 'id';

    protected $allowedFields = [
        'idAutomovel',
        'idAdicional'
    ];
}