<?php
namespace App\Models;
use CodeIgniter\Model;

class AutomovelModel extends Model
{
    protected $table = 'automoveis';
    protected $primaryKey = 'id';

    protected $allowedFields = [
        'descricao',
        'placa',
        'codigo_renavam',
        'ano_modelo',
        'ano_fabricacao',
        'cor',
        'km',
        'marca',
        'preco',
        'preco_fipe'
    ];
}