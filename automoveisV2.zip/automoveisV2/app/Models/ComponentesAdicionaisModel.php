<?php
namespace App\Models;
use CodeIgniter\Model;

class ComponentesAdicionaisModel extends Model
{
    protected $table = 'componentes_adicionais';
    protected $primaryKey = 'id';

    protected $allowedFields = [
        'ar_condicionado',
        'direcao_hidraulica',
        'airbag',
        'cd_player',
        'vidro_eletrico',
        'trava_eletrica',
        'cambio_automatico',
        'rodas_liga',
        'alarme'
    ];
}