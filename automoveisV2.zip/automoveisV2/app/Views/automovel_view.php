<!doctype html>
<html lang="en">
  <head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>CRUD Automóveis</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
</head>
<body>
<div class="container mt-4">
    <div class="d-flex justify-content-end">
        <a href="<?php echo site_url('/automovel-form') ?>" class="btn btn-success mb-2"><i class="bi bi-plus-circle"></i></a>
          <button class="btn btn-danger mb-2 ml-2" 
            onclick="confirmMultiDelete()" 
            title="Apagar selecionados">
            <i class="bi bi-trash3"></i>
          </button>
	</div>
    <?php
     if(isset($_SESSION['msg'])){
        echo $_SESSION['msg'];
      }
     ?>
  <div class="mt-3">
     <table class="table table-bordered" id="automoveis-list">
       <thead>
          <tr>
             <!-- <th width='40px'>Cód.</th> -->
             <th width='20px' >
              <input type="checkbox" onclick="selectAll()" id='checkboxAll'>
             </th>
             <th>Descrição</th>
             <th width='150px'>Marca</th>
             <th width='80px' class='text-center'>Placa</th>
             <th width='60px' class='text-center'>Ações</th>
          </tr>
       </thead>
       <tbody>
          <?php if($automoveis): ?>
          <?php foreach($automoveis as $automovel): ?>
          <tr>
             <!-- <td class='text-center'>
              <?php echo $automovel['id']; ?>
             </td> -->
             <td class="text-center">
              <input type="checkbox" onclick="addSelects(<?php echo $automovel['id'];?>)" name="checkbox_<?php echo $automovel['id'];?>" value="<?php echo $automovel['id'];?>" class="checkbox" id="checkbox_<?php echo $automovel['id'];?>">
             </td>
             <td>
              <?php echo $automovel['descricao']; ?>
             </td>
             <td>
              <?php echo $automovel['marca']; ?>
             </td>
             <td class='text-center'>
              <?php echo $automovel['placa']; ?>
             </td>
             <td class='text-center'>
                <a href="<?php echo base_url('edit-view/'.$automovel['id']);?>" class="btn btn-secondary btn-sm" title='Editar'>
                <i class="bi bi-pencil"></i>
                </a>
               <a href="#" onclick="confirmDelete(<?php echo $automovel['id']; ?>)" class="btn btn-danger btn-sm" title='Apagar'>
                <i class="bi bi-trash3"></i>
               </a>
              </td>
          </tr>
         <?php endforeach; ?>
         <?php endif; ?>
       </tbody>
     </table>
  </div>
</div>
 
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
<script type="text/javascript" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready( function () {
      $('#automoveis-list').DataTable();
      $('#checkbox').removeClass('sorting_asc');
  } );
  
</script>
<script>
  var selected = [];

    function confirmDelete(id) {
      if (confirm("Deseja realmente excluir?")) {
        window.location.href = "<?php echo base_url('delete/'); ?>/" + id;
      }
    }

    function addSelects(id) {
      const check = $('#checkbox_' + id).prop('checked');

      if (!check && selected.includes(id)) {
        selected.splice(selected.indexOf(id), 1);
      } else if (check && !selected.includes(id)) {
        selected.push(id);
      }

      selected.sort()
      console.log(selected);
    }

    function selectAll() {
      const check = $('#checkboxAll').prop('checked');
      
      if (check) {
        $('.checkbox').each( function (check) {
          $(this).prop('checked', true);
          selected.push(parseInt(this.value));
        });
      } else {
        $('.checkbox').each( function (check) {
          $(this).prop('checked', false);
        });
        selected = [];
      }
        console.log(selected);
    }

    function confirmMultiDelete() {
      if (selected.length <= 0) {
        alert("Selecione registros para excluir!");
        return;
      }
      if (confirm("Deseja realmente excluir os registros selecionados?")) {
        window.location.href = "<?php echo base_url('deleteMulti/'); ?>/" + selected;
      }
    }
</script>
</body>
</html>