<!DOCTYPE html>
<html>
<head>
  <title>CRUD Automóveis</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <style>
    .container {
      max-width: 500px;
    }
    .error {
      display: block;
      padding-top: 5px;
      font-size: 14px;
      color: red;
    }
    .form-group {
      display: flex;
    }
  </style>
</head>
<body>
  <div class="container mt-5" style="max-width: 800px">
    <form method="post" id="update_automovel" name="update_automovel" 
    action="<?= site_url('/update') ?>">
      <input type="hidden" name="id" id="id" value="<?php echo isset($automovel_obj['id']) ? $automovel_obj['id'] : ''; ?>">
      <div class="mb-4">
        <h4>Dados cadastrais</h4>
        <hr>
      </div>
      <div class="form-group">
        <div class="w-50 p-1">
          <label for="descricao">Descrição</label>
          <input type="text" maxlength="60" name="descricao" id="descricao" class="form-control" value="<?php echo isset($automovel_obj['descricao']) ? $automovel_obj['descricao'] : ''; ?>">
        </div>
        <div class="w-25 p-1">        
          <label for="placa">Placa</label>
          <input type="text" maxlength="7" name="placa" id="placa" class="form-control" value="<?php echo isset($automovel_obj['placa']) ? $automovel_obj['placa'] : ''; ?>">
        </div>
        <div class="w-25 p-1">
          <label for="codigo_renavam">Código RENAVAM</label>
          <input type="text" maxlength="11" name="codigo_renavam" id="codigo_renavam" class="form-control" value="<?php echo isset($automovel_obj['codigo_renavam']) ? $automovel_obj['codigo_renavam'] : ''; ?>">
        </div>
      </div>
      <div class="form-group">
        <div class="w-25 p-1">
          <label for="ano_modelo">Ano modelo</label>
          <input type="number" maxlength="4" name="ano_modelo" id="ano_modelo" class="form-control" value="<?php echo isset($automovel_obj['ano_modelo']) ? $automovel_obj['ano_modelo'] : ''; ?>">
        </div>
        <div class="w-25 p-1">
          <label for="ano_fabricacao">Ano fabricação</label>
          <input type="number" maxlength="4" name="ano_fabricacao" id="ano_fabricacao" class="form-control" value="<?php echo isset($automovel_obj['ano_fabricacao']) ? $automovel_obj['ano_fabricacao'] : ''; ?>">
        </div>
        <div class="w-25 p-1">
          <label for="cor">Cor</label>
          <input type="text" maxlength="20" name="cor" id="cor" class="form-control" value="<?php echo isset($automovel_obj['cor']) ? $automovel_obj['cor'] : ''; ?>">
        </div>
        <div class="w-25 p-1">
          <label for="km">KM</label>
          <input type="number" maxlength="6" name="km" id="km" class="form-control" value="<?php echo isset($automovel_obj['km']) ? $automovel_obj['km'] : ''; ?>">
        </div>
      </div>
      <div class="form-group">
        <div class="w-50 p-1">
          <label for="marca">Marca</label>
          <input type="text" maxlength="20" name="marca" id="marca" class="form-control" value="<?php echo isset($automovel_obj['marca']) ? $automovel_obj['marca'] : ''; ?>">
        </div>
        <div class="w-25 p-1">
          <label for="preco">Preço</label>
          <input type="number" maxlength="11" step=".01" name="preco" id="preco" class="form-control" value="<?php echo isset($automovel_obj['preco']) ? $automovel_obj['preco'] : ''; ?>">
        </div>
        <div class="w-25 p-1">
          <label for="preco_fipe">Preço FIPE</label>
          <input type="number" maxlength="11" step=".01" name="preco_fipe" id="preco_fipe" class="form-control" value="<?php echo isset($automovel_obj['preco_fipe']) ? $automovel_obj['preco_fipe'] : ''; ?>">
        </div>
      </div>
      <div class="mt-5 mb-4">
        <h4>Componentes adicionais</h4>
        <hr>
      </div>

      <div class='form-group'>
<?php if($componentes): ?>
          <?php 
            $i = 0; 
            foreach($componentes as $componente): 
              
                if ($i == 4) { echo "</div><div class='form-group'>"; $i = 0; } $i++; ?>
                <div class="w-25 p-1">
                  <input style="width: 15px" <?php echo isset($componente['checked']) ? $componente['checked'] : ''; ?> type="checkbox" name="componentes[<?php echo $componente['descricao'];?>]" id="<?php echo $componente['descricao'];?>" value="<?php echo $componente['id'];?>">
                  <label for="<?php echo $componente['descricao'];?>">
                    <?php echo $componente['nome'];?>
                  </label>
                </div>
          <?php endforeach; ?>
          <?php endif; ?>
              </div>

      <div class="form-group" style="display: block; text-align: end;">
        <a href="<?php echo site_url('/') ?>" class="btn btn-secondary pr-3 pl-3 mr-1"><i class="bi bi-back"></i> Voltar</a>
        <button type="submit" class="btn btn-success pr-3 pl-3">Salvar</button>
      </div>
    </form>
  </div>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/additional-methods.min.js"></script>
  <script>
    if ($("#update_automovel").length > 0) {
      $("#update_automovel").validate({
        rules: {
          descricao: {
            required: true,
            maxlength: 60,
          },
          placa: {
            required: true,
            maxlength: 7,
            minlength: 7,
          },
          codigo_renavam: {
            required: true,
            maxlength: 11,
          },
          ano_modelo: {
            required: true,
            range: [1920, 2025]
          },
          ano_fabricacao: {
            required: true,
            range: [1920, 2023]
          },
          cor: {
            required: true,
            maxlength: 20,
          },
          km: {
            required: true,
            maxlength: 6,
          },
          marca: {
            required: true,
            maxlength: 20,
          },
          preco: {
            required: true,
            maxlength: 11,
            range: [0.00, 999999.99]
          },
          preco_fipe: {
            required: true,
            maxlength: 11,
            range: [0.00, 999999.99]
          },
        },
        messages: {
          descricao: {
            required: "A descrição é obrigatória.",
            maxlength: "A descrição pode conter até 60 caracteres.",
          },
          placa: {
            required: "A placa é obrigatória.",
            maxlength: "A placa deve conter 7 caracteres.",
            minlength: "A placa deve conter 7 caracteres.",
          },
          codigo_renavam: {
            required: "O código RENAVAM é obrigatório.",
            maxlength: "O código RENAVAM pode conter até 11 caracteres.",
          },
          ano_modelo: {
            required: "O ano modelo é obrigatório.",
          },
          ano_fabricacao: {
            required: "O ano fabricação é obrigatório.",
          },
          cor: {
            required: "A cor é obrigatória.",
            maxlength: "A cor pode conter até 20 caracteres.",
          },
          km: {
            required: "A quilometragem é obrigatória.",
            maxlength: "A quilometragem pode conter até 6 caracteres.",
          },
          marca: {
            required: "A marca é obrigatória.",
            maxlength: "A marca pode conter até 20 caracteres.",
          },
          preco: {
            required: "O preço é obrigatório.",
            maxlength: "O preço pode conter até 11 caracteres.",
            range: "Informe um valor entre 0,00 e 999999,99",
          },
          preco_fipe: {
            required: "O preço FIPE é obrigatório.",
            maxlength: "O preço FIPE pode conter até 11 caracteres.",
            range: "Informe um valor entre 0,00 e 999999,99",
          },
        },
      })
    }
  </script>
  <!--<script>
    $(document).ready( function () {
      $(':checkbox').each( function () {
        if (this.value === "1") {
          $(this).prop('checked', true);
        }
        });
      });
  </script>
  <script>
    $(':checkbox').change(function(){
    this.value = (Number(this.checked));
});
  </script> -->
</body>
</html>